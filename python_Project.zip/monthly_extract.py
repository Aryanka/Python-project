import sqlite3
import sys,datetime
roll_no=int(input("Enter Roll No of Student: "))
month=int(input("Enter Month of students: "))
year=int(input("Enter year of student : "))

def viewall(roll_no,month,year):
    sdate=datetime.date(year,month,1)
    edate=datetime.date(year,month,30)
    conn = sqlite3.connect("college.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM attendance where roll_no=? and day>=? and day<=? ", (roll_no,sdate,edate))
    global data
    data= cur.fetchall()

def feedfile(data):
    f = open('student_details_for_a_month.csv','w')
    for row in data:
        for ele in row:
            f.write(str(ele))
            f.write(',')
        f.write('\n')
    f.close()
viewall(roll_no,month,year)
feedfile(data)
